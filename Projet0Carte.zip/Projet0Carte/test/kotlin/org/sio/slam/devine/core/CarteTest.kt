package org.sio.slam.devine.core

import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class CarteTest {

    @Test
    fun getValeur() {
    }
}